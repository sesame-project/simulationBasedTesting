import subprocess
import Pyro5.api
import threading
import time
import uuid

from enum import IntEnum

#https://stackoverflow.com/questions/36932/how-can-i-represent-an-enum-in-python

# Circus: https://circus.readthedocs.io/en/latest/for-devs/library/#library
# Circus library can test e.g. the process status

# Worker daemon should also support STOP method... to e.g. terminate a test early
# Pre-test 

VERSION_ID = 0.15

#EXPT_RUNNER_CMD = "./execute_testrunner_stub.sh"

# TODO: replace these with script references into the project directory
EXPT_RUNNER_CMD = "/home/jharbin/academic/sesame/WP6/simulationBasedTesting/uk.ac.york.sesame.testing.evolutionary/scripts/execute_testrunner_soprano.sh"

COMPILE_RUNNER_CMD = "/home/jharbin/academic/sesame/WP6/simulationBasedTesting/uk.ac.york.sesame.testing.evolutionary/scripts/compile_project_soprano.sh"

RESYNC_RUNNER_CMD = "/home/jharbin/academic/sesame/WP6/simulationBasedTesting/uk.ac.york.sesame.testing.evolutionary/scripts/execute_testrunner_soprano.sh"

#BIND_ADDRESS = "192.168.1.239"
# TODO: need to lookup the bind address
BIND_ADDRESS = "192.168.1.19"

# TODO: this needs to be supplied in an experiment config
#RUN_PATH = "/home/jharbin/eclipse-workspace/PALTesting"
RUN_PATH = "/mnt/shared-soprano-code/"

class DepCheckCodes(IntEnum):
    DEPS_OK = 0
    MISSING_DEP = 1

class TestStatusCodes(IntEnum):
    RUNNING = 0
    COMPLETED = 1
    FAILED = 2

# TODO: experiment is also a test campaign
class ExptConfig:
    def __init__(self,expt_name, dependency_spec):
        # TODO: how to get the class ID included here
        # TODO: how to setup the metrics
        self.expt_name = expt_name
        self.unique_run_id = uuid.uuid4()
        self.dependency_spec = dependency_spec

    def preinit(self):
        print("Preinitialising experiment: " + str(self))
        # Need to ensure all the dependencies are ready here!
        # e.g. docker, java/maven packages - from dependency_spec
        script_output = subprocess.call([EXPT_RUNNER_CMD, str(self.test_id), RUN_PATH])
        return script_output

    def get_unique_run_id(self):
        return self.unique_run_id

class TestRunJob:
    def __init__(self,test_id):
        # TODO: how to get the class ID included here
        self.test_id = test_id
        self.unique_run_id = uuid.uuid4()

    def prepare(self):
        # TODO: do the resync of the directory here
        resync_output = 0
        if (resync_output == 0):
        # Do the compilation
            print("Performing compilation for " + self.test_id)
            script_output = subprocess.call([COMPILE_RUNNER_CMD, RUN_PATH])
            print("")
            return script_output
        else:
            return resync_output

    def execute(self):
        #Need to find named class file and generate the relevant run command!
        print("Executing job" + str(self))
        script_output = subprocess.call([EXPT_RUNNER_CMD, str(self.test_id), RUN_PATH])
        return script_output

    def handle_logs():
        return OK
    
    def handle():
        self.prepare()
        self.execute()
        self.copy_logs()

    def get_unique_run_id(self):
        return self.unique_run_id

class WorkManager:
    def __init__(self, name):
        self.pending_jobs = []
        self.watcher = threading.Thread(target=self.watch_job_queue, name="WorkManagerWatcher", daemon=True)
        self.current_expt = {}
        self.job_run_info = {}
        # This maps the job unqiue run ID to a hash of info
        self.watcher.start()

        # Need to ensure we cannot start an experiment before another is completed!

    def watch_job_queue(self):
        while True:
            print("Polling watch_job_queue - " + str(len(self.pending_jobs)) + " jobs")
            while len(self.pending_jobs) > 0:
                job = self.pending_jobs.pop()
                # Need to check nothing is running now!
                job.prepare()
                job.execute()
                time.sleep(1)
		# block for a moment before testing again
            time.sleep(1)

    def status_of_job(self, urun_id):
        # Need to verify if the process is still running!
        if urun_id in self.job_run_info:
            return self.job_run_info[urun_id]['status']
        else:
            return None
        
    def submit_test(self, j):
        self.pending_jobs.append(j)
        urun_id = j.get_unique_run_id()
        self.job_run_info[urun_id] = { 'status' : TestStatusCodes.RUNNING }
        print("Job Manager: added job "+ str(j) + "- queue length is now " + str(len(self.pending_jobs)))

    def submit_experiment(self, expt):
        self.current_expt = expt
        print("Set experiment to " + exptconfig)

jobmanager = WorkManager("SOPRANO")

@Pyro5.api.expose
class SopranoWorkerDaemon(object):

    def get_version_id(self):
        return VERSION_ID

    def init_experiment(self, expt_name_dsl, dependencies):
        expt= ExptConfig(expt_name_dsl, dependencies)
        urun_id = exptj.get_unique_run_id()
        print("Checking the configuration for experiment campaign name in DSL - " + str(expt_name_dsl))
        depstatus = jobmanager.check_dependencies(expt)
        if (depstatus == DepCheckCodes.DEPS_OK):
              print("Dependencies OK... submitting experiment to expt manager")
              submit_experiment(expt)
        else:
              print("Dependency error")
              # TODO: details about the missing dependency

    def submit_test(self, test_id):
        # Need to verify preconditions - e.g. are the classes/etc availble in the filesystem?
        testj = TestRunJob(test_id)
        urun_id = testj.get_unique_run_id()
        print("Submitted job to run test ID " + str(test_id))
        jobmanager.submit_test(testj)
        return urun_id

    def register_metrics_from_testrunner(self, timestamp, metric_name, metric_value):
        return 0

    def poll_for_status(urun_id):
        status = jobmanager.status_of_job(urun_id)
        print("poll_for_status for " + urun_id + " = " + status)
        return int(status)
    
    def poll_for_metrics():
        # TODO: Receive the pending metrics for this
        return []

    
daemon = Pyro5.api.Daemon(host=BIND_ADDRESS)
wd_uri = daemon.register(SopranoWorkerDaemon)
ns = Pyro5.core.locate_ns()

print("SOPRANO Worker Daemon Ready: Object uri =", wd_uri)       # print the uri so we can use it in the client later
ns.register("SOPRANOWorkerDaemon", wd_uri)

print("Registered with nameserver")
daemon.requestLoop()                    # start the event loop of the server to wait for calls
