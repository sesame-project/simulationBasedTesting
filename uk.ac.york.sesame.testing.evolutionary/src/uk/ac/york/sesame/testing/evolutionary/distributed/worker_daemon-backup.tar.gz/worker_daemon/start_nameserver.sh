#!/bin/sh
pyro5-ns -n 192.168.1.19
