#!/bin/sh

echo "Running expt $1 - $2" >> /tmp/aaa
sleep 10
