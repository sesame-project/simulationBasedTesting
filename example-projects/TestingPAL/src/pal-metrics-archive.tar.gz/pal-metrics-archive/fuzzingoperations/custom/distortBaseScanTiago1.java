package fuzzingoperations.custom;

public class distortBaseScanTiago1 extends distortBaseScan {
	private static final long serialVersionUID = 1L;

	protected String getTargetTopic() {
		return "/tiago_1/scan/";
	}
}
